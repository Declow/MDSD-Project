package robotdefinitionsample.models;

public enum ActionCondition {
    PICKUP,
	FORWARD,
	BACKWARD,
	TURN_CW,
	TURN_CCW,
	DO,
	TERMINATE,
	CONDITION,
	CONDITIONAT
}
