package robotdefinitionsample.interfaces;

import java.util.List;
import robotdefinitionsample.models.TaskItem;

public interface IConditionTasks {
    public void addTasks(List<TaskItem> items);
}
